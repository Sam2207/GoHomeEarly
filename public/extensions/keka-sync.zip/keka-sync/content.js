function extract() {
  const text = document.body.innerText;
  const lines = text.split("\n");

  let data = {};
  let foundDays = new Set();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (
      (line.includes("Mon") ||
       line.includes("Tue") ||
       line.includes("Wed") ||
       line.includes("Thu") ||
       line.includes("Fri"))
    ) {
      const nextLine = lines[i + 1];
      if (!nextLine) continue;

      const match = nextLine.match(/(\d+)h\s*(\d+)m/);
      if (!match) continue;

      const formatted = `${match[1]}:${match[2].padStart(2, "0")}`;

      if (line.includes("Mon") && !data.mon) { data.mon = formatted; foundDays.add("mon"); }
      if (line.includes("Tue") && !data.tue) { data.tue = formatted; foundDays.add("tue"); }
      if (line.includes("Wed") && !data.wed) { data.wed = formatted; foundDays.add("wed"); }
      if (line.includes("Thu") && !data.thu) { data.thu = formatted; foundDays.add("thu"); }
      if (line.includes("Fri") && !data.fri) { data.fri = formatted; foundDays.add("fri"); }

      // stop when all weekdays found
      if (foundDays.size === 5) break;
    }
  }

  console.log("✅ Latest Week:", data);

  if (Object.values(data).some(v => v)) {
    chrome.storage.local.set({ kekaData: data });
  }
}

// wait for page render
setTimeout(extract, 3000);