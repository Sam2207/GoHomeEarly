function toMinutes(val) {
  if (!val || !val.includes(":")) return 0;
  let [h, m] = val.split(":").map(Number);
  return h * 60 + m;
}

function getTodayKey() {
  const map = ["sun","mon","tue","wed","thu","fri","sat"];
  return map[new Date().getDay()];
}

function calc(data) {
  const avgPerDay = 8 * 60;
  const weeklyTarget = avgPerDay * 5;

  let total = 0;
  let earlyDays = 0;
  let filledDays = 0;

  const days = ["mon","tue","wed","thu","fri"];

  days.forEach(d => {
    if (data[d]) {
      const mins = toMinutes(data[d]);
      total += mins;
      filledDays++;

      if (mins < avgPerDay) earlyDays++;
    }
  });

  const remaining = weeklyTarget - total;
  const remainingDays = 5 - filledDays;

  let result = `Total: ${Math.floor(total/60)}h ${total%60}m\n`;

  let statusClass = "neutral";

  // 🎯 TODAY LOGIC
  const today = getTodayKey();
  const todayMinutes = toMinutes(data[today] || "0:0");

  if (remaining <= 0) {
    result += "✅ You can go home now";
    statusClass = "good";
    return { result, statusClass };
  }

  result += `Remaining: ${Math.floor(remaining/60)}h ${remaining%60}m\n`;

  if (earlyDays > 2) {
    result += "❌ Early leave limit exceeded";
    statusClass = "bad";
    return { result, statusClass };
  }

  // 🔥 Today decision
  if (todayMinutes > 0 && todayMinutes < avgPerDay) {
    result += `\n🟢 You can leave early today`;
    statusClass = "good";
  } else {
    statusClass = "neutral";
  }

  if (remainingDays > 0) {
    const perDay = Math.ceil(remaining / remainingDays);
    result += `\nNeed ${Math.floor(perDay/60)}h ${perDay%60}m/day`;
  }

  result += `\nEarly days used: ${earlyDays}/2`;

  return { result, statusClass };
}

function updateCalculation() {
  let data = {};
  ["mon","tue","wed","thu","fri"].forEach(id => {
    data[id] = document.getElementById(id).value;
  });

  const { result, statusClass } = calc(data);

  const statusEl = document.getElementById("status");
  statusEl.innerText = result;
  statusEl.className = "status " + statusClass;
}

function load() {
  chrome.storage.local.get("kekaData", (result) => {
    const data = result.kekaData || {};

    if (!Object.keys(data).length) {
      document.getElementById("status").innerText = "Open Keka first";
      return;
    }

    ["mon","tue","wed","thu","fri"].forEach(id => {
      document.getElementById(id).value = data[id] || "";
    });

    updateCalculation();
  });
}

// 🚀 Auto run
load();

// ⚡ Live update
["mon","tue","wed","thu","fri"].forEach(id => {
  document.getElementById(id).addEventListener("input", updateCalculation);
});